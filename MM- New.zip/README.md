# Hotel Ops Pro

A browser-based hotel operations app — no build step, no framework, no npm.

**Live demo:** https://YOUR-USERNAME.github.io/hotel-ops-pro

---

## Features

- **Schedule** — Weekly board with all departments, seniority-sorted staff, coverage needs, quick-fill shifts, split shifts, publish/draft mode
- **Request offs** — List / Daily / Weekly / Monthly views, approve/deny in-grid, division & department filters, seniority sort
- **Statistics** — Live approval rates, request type breakdown, call-off log, denied log
- **Inventory** — Supplies vs par (LOW badges, ±1 adjusters), equipment condition tracker
- **Profiles** — All staff with hire date, tenure, PTO balances, department filter
- **Housekeeping** — Duty roster (schedule cross-reference, floor/section, credits, check-outs, double beds, totals), roles panel, daily summary with diffs, Assignments (VIPs, traces, OOS/OOO, projects by role)

---

## File structure

```
hotel-ops-pro/
├── index.html    ← HTML shell — all tab markup
├── styles.css    ← All styles (CSS custom properties for easy theming)
├── data.js       ← Staff, QUICK times, inventory, HK roster, assignment flags
├── utils.js      ← Pure helpers: date math, time parser/formatter, name lookup
├── storage.js    ← Save/load layer (localStorage or Claude artifact API)
├── app.js        ← All render functions and event handlers
└── README.md
```

---

## Running locally

1. Clone the repo:
   ```bash
   git clone https://github.com/YOUR-USERNAME/hotel-ops-pro.git
   cd hotel-ops-pro
   ```

2. **Enable localStorage** — open `storage.js` and uncomment the `window.storage` block (lines 15–27). Comment out or delete the note about Option B. That's the only code change needed to run outside Claude.

3. Open `index.html` in Chrome, Firefox, or Edge. No server required.

4. Data persists automatically in your browser's localStorage under the key `hotel_ops_pro_v39`.

---

## Deploying to GitHub Pages

See step-by-step instructions below. Once deployed, the app lives at:
`https://YOUR-USERNAME.github.io/hotel-ops-pro`

---

## Editing guide

### Add or edit a staff member
Open `data.js` and find the `PROFILES` array. Use the `P()` helper:
```js
P('s99', 'Jane', 'Doe', 'Front Desk', 'rooms', '2024-01-01', 480, 990, [0, 6])
//  id    first   last   department    division  hire-date    start end  days-off
```
Days-off: `0` = Sunday, `1` = Monday … `6` = Saturday.

### Change quick-fill buttons for a department
Edit the `QUICK` object in `data.js`. Values are **minutes from midnight**:
```js
'Front Desk': [420, 870, 1380]
// 420 = 7:00 AM   870 = 2:30 PM   1380 = 11:00 PM
```

### Add a new department
1. Add its name to the relevant `depts` array inside `DIVS` in `data.js`.
2. Add its entry to `QUICK`.
3. Coverage `NEEDS` auto-seeds to `[2,2,2,2,2,2,2]`; override as needed.

### Change the color scheme
All colors are CSS custom properties at the top of `styles.css` under `:root`. Division header colors live in the `DIVS[].color` entries in `data.js`.

### Add a housekeeping room attendant
Add a row to `HK_FLOORS` in `data.js`. The app auto-creates a Housekeeping profile for any name not already in `PROFILES`.

### Storage key
All data saves under `hotel_ops_pro_v39`. Change `KEY` in `data.js` to wipe and start fresh.

---

## Architecture notes

- Vanilla HTML/CSS/JS — no React, no Vue, no bundler.
- All render functions are top-level globals in `app.js` (`renderSched()`, `renderHK()`, etc.) and called from `onclick` attributes in the HTML.
- State is a single JSON blob; `schedSave()` debounces writes by 2 s, `hopSave(true)` writes immediately.
- `storage.js` is the only file you need to change to switch backends (localStorage ↔ Claude API).

---

## License

MIT — use freely, modify freely.
