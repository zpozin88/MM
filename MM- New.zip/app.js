// ─── APP.JS ──────────────────────────────────────────────────────────────────
// Hotel Ops Pro v42 — main application logic
// Depends on: data.js, utils.js, storage.js (load all three before this file)
// ─────────────────────────────────────────────────────────────────────────────

// ── Tab & sub-tab routing ─────────────────────────────────────────────────────
window.hopTab = function(pg){
  document.querySelectorAll('.hop .top-tab').forEach(t=>t.classList.toggle('active',t.dataset.pg===pg));
  document.querySelectorAll('.hop .page').forEach(p=>p.classList.toggle('active',p.id==='pg-'+pg));
  try{
    if(pg==='sched'){ renderReq(); if(el('ss-wk').style.display!=='none') renderSched(); }
    if(pg==='stats') renderStats();
    if(pg==='inv')   renderInv();
    if(pg==='prof')  renderProf();
    if(pg==='hk'){ renderHK(); if(el('st-assign').style.display!=='none') renderAssign(); }
  }catch(e){ console.warn('Tab render error:',e); }
};

window.schedSub = function(ss){
  document.querySelectorAll('#pg-sched > .sub-tabs .sub-tab').forEach(t=>t.classList.toggle('active',t.dataset.ss===ss));
  el('ss-req').style.display = ss==='req'?'block':'none';
  el('ss-wk').style.display  = ss==='wk' ?'block':'none';
  if(ss==='req') renderReq(); else renderSched();
};

window.hopSub = function(st){
  document.querySelectorAll('#pg-hk > .sub-tabs .sub-tab[data-st]').forEach(t=>t.classList.toggle('active',t.dataset.st===st));
  el('st-roster').style.display = st==='roster'?'block':'none';
  el('st-assign').style.display = st==='assign'?'block':'none';
  if(st==='assign') renderAssign(); else renderHK();
};

// ── Schedule helpers ──────────────────────────────────────────────────────────
let WS = sunday(today);   // current week-start

function getD(sid, ds){
  const k = ck(sid,ds); if(CD[k]) return CD[k];
  const p = prof(sid);  if(!p) return {pto:'OFF'};
  const day = fromDs(ds).getDay();
  return p.offs.includes(day) ? {pto:'OFF'} : {s:p.ps, e:p.pe};
}
function ck(sid,ds){ return sid+'_'+ds; }
function setD(sid,ds,val){ CD[ck(sid,ds)]=val; schedSave(); }
function isPub(){ return !!PUB[dstr(WS)]; }
function schedCount(dept,ds){
  return PROFILES.filter(p=>p.dept===dept).filter(p=>{ const c=getD(p.id,ds); return !c.pto&&c.s!=null; }).length;
}

// ── Week navigation ───────────────────────────────────────────────────────────
window.wkNav    = n => { WS=addD(WS,7*n); renderSched(); };
window.wkToday  = ()=> { WS=sunday(today); renderSched(); };
window.togglePub= ()=>{
  const k=dstr(WS); if(PUB[k]) delete PUB[k]; else PUB[k]=true;
  schedSave(); renderSched();
};

// ── Division / department nav ─────────────────────────────────────────────────
let selDiv='ALL', selDept='ALL';
function renderNav(){
  el('navDiv').innerHTML =
    '<div class="ntab'+(selDiv==='ALL'?' active':'')+'" style="--dv:#111;" onclick="setDiv(\'ALL\')">All divisions</div>'
    +DIVS.map(d=>'<div class="ntab'+(d.id===selDiv?' active':'')+'" style="--dv:'+d.color+';" onclick="setDiv(\''+d.id+'\')">'+d.name+'</div>').join('');
  const depts = selDiv==='ALL'?DIVS.flatMap(d=>d.depts):DIVS.find(d=>d.id===selDiv).depts;
  el('navDept').innerHTML =
    '<div class="ntab'+(selDept==='ALL'?' active':'')+'" onclick="setDept(\'ALL\')">All departments</div>'
    +depts.map(dp=>'<div class="ntab'+(dp===selDept?' active':'')+'" onclick="setDept(\''+dp.replace(/'/g,"\\'")+'\')">'
      +dp+(dp==='Housekeeping'?' <button class="btn" style="font-size:10px;padding:0 6px;margin-left:8px;background:rgba(255,255,255,.2);color:#fff;border-color:rgba(255,255,255,.5);" onclick="event.stopPropagation();hopTab(\'hk\')">Duty roster &#8594;</button>':'')
      +'</div>').join('');
}
window.setDiv  = id => { selDiv=id; selDept='ALL'; renderSched(); };
window.setDept = dp => { selDept=dp; renderSched(); };

// ── Cell builder ──────────────────────────────────────────────────────────────
function splitKid(kid){ const i=kid.indexOf('_'); return [kid.slice(0,i),kid.slice(i+1)]; }
function reqsFor(sid,ds){ return REQS.filter(r=>r.sid===sid&&ds>=r.s&&ds<=r.e); }

function cellHTML(p, ds){
  const c=getD(p.id,ds), rq=reqsFor(p.id,ds);
  let cls='sc', rqi='';
  if(rq.length){
    const st=rq[0].status;
    cls+=st==='pending'?' rq-p':st==='approved'?' rq-a':' rq-d';
    rqi='<span class="rqi">'+(st==='pending'?'⏳':st==='approved'?'✓':'✗')+'</span>';
  }
  if(c.pto) cls+=' p'+c.pto;
  const kid=p.id+'_'+ds;

  if(isPub()){
    let inner;
    if(c.pto) inner='<span class="ptag t-'+c.pto+'" style="margin:0;padding:3px 0;">'+(c.pto==='REMOTE'?'🏠 REMOTE':c.pto)+'</span>';
    else inner='<div class="pubt">'+fmtT(c.s)+'</div><div class="pubt" style="color:#555;">'+fmtT(c.e)+'</div>'+(c.s2!=null?'<div style="font-size:11px;color:#888;">+ '+fmtT(c.s2)+'–'+fmtT(c.e2)+'</div>':'');
    return '<td class="pubc '+(c.pto?'p'+c.pto:'')+' '+cls.split(' ').filter(x=>x.startsWith('rq')).join(' ')+'">'+inner+'</td>';
  }

  if(p.mgr){
    const q='<div class="qg" style="grid-template-columns:1fr 1fr;">'
      +'<button class="qb off" onclick="mgrPto(\''+kid+'\',\'OFF\')">OFF</button>'
      +'<button class="qb vac" onclick="mgrPto(\''+kid+'\',\'VAC\')">VAC</button>'
      +'<button class="qb sick" onclick="mgrPto(\''+kid+'\',\'SICK\')">SICK</button>'
      +'<button class="qb per" onclick="mgrPto(\''+kid+'\',\'PER\')">PER</button>'
      +'<button class="qb rem" onclick="mgrPto(\''+kid+'\',\'REMOTE\')">🏠 REMOTE</button></div>';
    if(c.pto) return '<td class="'+cls+'">'+rqi+'<span class="ptag t-'+c.pto+'">'+(c.pto==='REMOTE'?'🏠 REMOTE':c.pto)+'</span>'+q+'</td>';
    return '<td class="'+cls+'">'+rqi+'<div style="display:flex;gap:3px;align-items:center;justify-content:center;margin-top:8px;"><span style="font-size:11px;color:#888;">Start</span><input class="tin" value="'+fmtT(c.s)+'" onchange="onMgrIn(\''+kid+'\',this)"></div><div class="hrl">'+(c.s!=null?fmtT(c.s)+'–'+fmtT(c.e):'')+'</div>'+q+'</td>';
  }

  const qk = QUICK[p.dept]||[480,540,600];
  const btns='<div class="qg">'
    +qk.map(t=>'<button class="qb f" onclick="quick(\''+kid+'\','+t+')">'+fmtT(t).replace(':00','')+'</button>').join('')
    +'<button class="qb off"  onclick="ptoSet(\''+kid+'\',\'OFF\')">OFF</button>'
    +'<button class="qb vac"  onclick="ptoSet(\''+kid+'\',\'VAC\')">VAC</button>'
    +'<button class="qb sick" onclick="ptoSet(\''+kid+'\',\'SICK\')">SICK</button></div>';

  if(c.pto) return '<td class="'+cls+'">'+rqi+'<span class="ptag t-'+c.pto+'">'+c.pto+'</span>'+btns+'</td>';

  const split = c.s2!==undefined
    ?'<div class="split2"><span class="s2l">2ND</span><button class="s2x" onclick="rmSplit(\''+kid+'\')">✗</button>'
      +'<div style="display:flex;gap:2px;margin-top:1px;">'
      +'<input class="tin" value="'+fmtT(c.s2)+'" onchange="onSplit(\''+kid+'\',\'s2\',this)">'
      +'<input class="tin" value="'+fmtT(c.e2)+'" onchange="onSplit(\''+kid+'\',\'e2\',this)"></div></div>':'' ;
  const addSplit = c.s2===undefined?'<button class="spb" title="Add second shift" onclick="addSplitFn(\''+kid+'\')">✛</button>':'';

  return '<td class="'+cls+'">'+rqi+addSplit
    +'<div style="display:flex;gap:2px;margin-top:'+(rq.length?'12px':'10px')+';"><input class="tin" id="in_'+kid+'" value="'+fmtT(c.s)+'" placeholder="in" onchange="onIn(\''+kid+'\',this)"><input class="tin" id="out_'+kid+'" value="'+fmtT(c.e)+'" placeholder="out" onchange="onOut(\''+kid+'\',this)"></div>'
    +'<div class="hrl" id="hr_'+kid+'">'+(hrsOf(c)?hrsOf(c).toFixed(1)+'h':'')+'</div>'+btns+split+'</td>';
}

// Cell event handlers
window.onIn=function(kid,inp){
  const[sid,ds]=splitKid(kid); const m=parseT(inp.value); if(m==null){inp.value='';return;}
  const c=Object.assign({},getD(sid,ds)); delete c.pto; c.s=m; c.e=Math.min(1439,m+510);
  setD(sid,ds,c); const o=el('out_'+kid); if(o){o.value=fmtT(c.e);o.classList.add('flash');setTimeout(()=>o.classList.remove('flash'),700);}
  inp.value=fmtT(m); const h=el('hr_'+kid); if(h) h.textContent=hrsOf(c).toFixed(1)+'h';
};
window.onOut=function(kid,inp){
  const[sid,ds]=splitKid(kid); const m=parseT(inp.value); if(m==null){inp.value='';return;}
  const c=Object.assign({},getD(sid,ds)); delete c.pto; c.e=m; setD(sid,ds,c);
  inp.value=fmtT(m); const h=el('hr_'+kid); if(h) h.textContent=hrsOf(c).toFixed(1)+'h';
};
window.onMgrIn=function(kid,inp){
  const[sid,ds]=splitKid(kid); const m=parseT(inp.value); if(m==null){inp.value='';return;}
  setD(sid,ds,{s:m,e:Math.min(1439,m+510)}); renderSched();
};
window.quick=function(kid,t){ const[sid,ds]=splitKid(kid); setD(sid,ds,{s:t,e:Math.min(1439,t+510)}); renderSched(); };
window.ptoSet=function(kid,p){ const[sid,ds]=splitKid(kid); const cur=getD(sid,ds); setD(sid,ds,cur.pto===p?{s:prof(sid).ps,e:prof(sid).pe}:{pto:p}); renderSched(); };
window.mgrPto=function(kid,p){ const[sid,ds]=splitKid(kid); const cur=getD(sid,ds); setD(sid,ds,cur.pto===p?{s:prof(sid).ps,e:Math.min(1439,prof(sid).ps+510)}:{pto:p}); renderSched(); };
window.addSplitFn=function(kid){ const[sid,ds]=splitKid(kid); const c=Object.assign({},getD(sid,ds)); c.s2=null; c.e2=null; setD(sid,ds,c); renderSched(); };
window.rmSplit=function(kid){ const[sid,ds]=splitKid(kid); const c=Object.assign({},getD(sid,ds)); delete c.s2; delete c.e2; setD(sid,ds,c); renderSched(); };
window.onSplit=function(kid,f,inp){ const[sid,ds]=splitKid(kid); const m=parseT(inp.value); const c=Object.assign({},getD(sid,ds)); c[f]=m; if(f==='s2'&&m!=null&&c.e2==null) c.e2=Math.min(1439,m+240); setD(sid,ds,c); renderSched(); };
window.needSet=function(dept,i,v){ const n=parseInt(v); NEEDS[dept][i]=isNaN(n)?0:n; schedSave(); renderSched(); };

// ── Department block builder ───────────────────────────────────────────────────
function deptBlock(dept, showHdr){
  const dv=divOf(dept);
  const staff=PROFILES.filter(p=>p.dept===dept).sort((a,b)=>a.hire.localeCompare(b.hire));
  if(!staff.length) return '';
  let h='';
  const cols=isPub()?8:9;
  if(showHdr) h+='<tr><td class="depthdr" colspan="'+cols+'" style="background:'+dv.color+';">'
    +dept+' <span style="font-weight:400;opacity:.8;">· '+dv.name+' · '+staff.length+' staff</span>'
    +(dept==='Housekeeping'?' <button class="btn" style="font-size:10px;padding:0 6px;margin-left:8px;background:rgba(255,255,255,.2);color:#fff;border-color:rgba(255,255,255,.5);" onclick="hopTab(\'hk\')">Duty roster →</button>':'')
    +'</td></tr>';
  if(!isPub()){
    h+='<tr class="needr"><td class="nc" style="background:#FFFBEB;border:1.5px solid #C8A000;"><span style="font-size:11px;font-weight:500;color:#633806;">Need / Scheduled</span></td>';
    for(let d=0;d<7;d++){
      const ds=dstr(addD(WS,d)), need=NEEDS[dept][d], got=schedCount(dept,ds), ok=got>=need;
      h+='<td style="text-align:center;padding:3px;"><input class="ndin" value="'+need+'" onchange="needSet(\''+dept.replace(/'/g,"\\'")+'\','+d+',this.value)"> <span class="'+(ok?'ndok':'ndshort')+'">'+got+(ok?' ✓':' short')+'</span></td>';
    }
    h+='<td style="background:#FFFBEB;"></td></tr>';
  }
  staff.forEach(p=>{
    let wk=0; for(let d=0;d<7;d++) wk+=hrsOf(getD(p.id,dstr(addD(WS,d))));
    h+='<tr><td class="nc"><div class="ncn">'+p.first+' '+p.last+(p.mgr?' <span style="font-size:10px;color:#534AB7;">MGR</span>':'')+(p.auto?' <span style="font-size:10px;color:#854F0B;">RA</span>':'')+'</div><div class="ncs">Since '+p.hire.slice(0,4)+' · '+tenure(p.hire)+'y</div></td>';
    for(let d=0;d<7;d++) h+=cellHTML(p,dstr(addD(WS,d)));
    if(!isPub()) h+='<td class="hcol">'+wk.toFixed(1)+'</td>';
    h+='</tr>';
  });
  return h;
}

// ── Main schedule render ───────────────────────────────────────────────────────
function renderSched(){
  renderNav();
  el('wkLbl').textContent=MO[WS.getMonth()]+' '+WS.getDate()+' – '+MO[addD(WS,6).getMonth()]+' '+addD(WS,6).getDate()+', '+addD(WS,6).getFullYear();
  el('pubBtn').textContent=isPub()?'Revise schedule':'Publish schedule';
  const pb=el('pubBar');
  if(isPub()){ pb.className='pubbar live'; pb.innerHTML='Published — schedule is locked and compact. Use Revise to edit.'; }
  else{ pb.className='pubbar draft'; pb.innerHTML='Draft — edits are live; publish when the week is final.'; }
  let depts;
  if(selDept!=='ALL') depts=[selDept];
  else if(selDiv!=='ALL') depts=DIVS.find(d=>d.id===selDiv).depts;
  else depts=DIVS.flatMap(d=>d.depts);
  let h='<thead><tr><th style="text-align:left;padding-left:8px;">Team member</th>';
  for(let d=0;d<7;d++){ const dt=addD(WS,d); h+='<th class="'+(dt.getTime()===today.getTime()?'tc':'')+'">'+SD[d]+'<br><span style="font-weight:400;font-size:11px;">'+MO[dt.getMonth()]+' '+dt.getDate()+'</span></th>'; }
  if(!isPub()) h+='<th>Hrs</th>';
  h+='</tr></thead><tbody>';
  const showHdr=depts.length>1;
  depts.forEach(dp=>{ h+=deptBlock(dp,showHdr); });
  h+='</tbody>';
  el('sgTbl').innerHTML=h;
  updBadge();
}

// ── Request offs ──────────────────────────────────────────────────────────────
let reqView='week', dayCur=new Date(today), wkR=sunday(today);
let calM=new Date(today.getFullYear(),today.getMonth(),1);

window.setReqView=v=>{ reqView=v; renderReq(); };
window.dayNav   =n=>{ dayCur=addD(dayCur,n); renderReq(); };
window.dayJump  =v=>{ if(v) dayCur=fromDs(v); renderReq(); };
window.wkRNav   =n=>{ wkR=addD(wkR,7*n); renderReq(); };
window.calNav   =n=>{ calM=new Date(calM.getFullYear(),calM.getMonth()+n,1); renderReq(); };
window.cellJump =ds=>{ dayCur=fromDs(ds); reqView='day'; renderReq(); };

function eachDay(s,e,fn){ let d=fromDs(s);const end=fromDs(e);while(d<=end){fn(dstr(d));d=addD(d,1);} }
function applyReq(r)  { eachDay(r.s,r.e,ds=>{CD[ck(r.sid,ds)]={pto:r.type};}); }
function unapplyReq(r){ eachDay(r.s,r.e,ds=>{const k=ck(r.sid,ds);if(CD[k]&&CD[k].pto===r.type)delete CD[k];}); }

function seedReqs(){
  const w=d=>dstr(addD(WS,d));
  REQS=[
    {id:'r1',sid:'s2',type:'VAC', s:w(2), e:w(2), note:'Family trip',   status:'pending'},
    {id:'r2',sid:'s1',type:'SICK',s:w(3), e:w(4), note:'Medical',       status:'approved'},
    {id:'r3',sid:'s3',type:'PER', s:w(5), e:w(5), note:'Personal day',  status:'denied'},
    {id:'r4',sid:'s2',type:'VAC', s:w(16),e:w(20),note:'Cruise',        status:'pending'},
    {id:'r5',sid:'s4',type:'VAC', s:w(9), e:w(11),note:'Long weekend',  status:'approved'},
    {id:'r6',sid:'s10',type:'PER',s:w(8), e:w(8), note:'Appointment',   status:'pending'},
    {id:'r7',sid:'s12',type:'FMLA',s:w(14),e:w(28),note:'Leave',        status:'approved'},
    {id:'r8',sid:'s13',type:'VAC',s:w(23),e:w(24),note:'Concert',       status:'denied'},
    {id:'r9',sid:'s15',type:'VAC',s:w(30),e:w(34),note:'Fishing trip',  status:'pending'}
  ];
  REQS.filter(r=>r.status==='approved').forEach(applyReq);
}

function updBadge(){
  const n=REQS.filter(r=>r.status==='pending').length;
  ['reqBadge','reqBadge2'].forEach(id=>{ const b=el(id); if(b){ b.textContent=n; b.style.display=n?'inline':'none'; } });
}

function rTypeCls(t){ return t==='VAC'?'st-approved':t==='SICK'||t==='FMLA'?'st-denied':'st-pending'; }

function rfDivChange(){
  const v=el('rfDiv').value;
  const opts=v==='all'?DIVS.flatMap(d=>d.depts):DIVS.find(d=>d.id===v).depts;
  el('rfDept').innerHTML='<option value="all">All departments</option>'+opts.map(d=>'<option>'+d+'</option>').join('');
  renderReq();
}
window.rfDivChange=rfDivChange;

window.submitReq=function(){
  const sid=el('rqSid').value,t=el('rqType').value,s=el('rqS').value,e=el('rqE').value||s,n=el('rqN').value;
  if(!sid||!s)return;
  REQS.push({id:'r'+Date.now(),sid,type:t,s,e,note:n,status:'pending'});
  el('rqN').value=''; schedSave(); renderReq();
};
window.decide=function(id,st){
  const r=REQS.find(x=>x.id===id); if(!r)return;
  if(r.status==='approved') unapplyReq(r); r.status=st;
  if(st==='approved') applyReq(r); schedSave(); renderReq();
};
window.undoReq=function(id){
  const r=REQS.find(x=>x.id===id); if(!r)return;
  if(r.status==='approved') unapplyReq(r); r.status='pending'; schedSave(); renderReq();
};

function reqDepts(){
  const fd=el('rfDept').value||'all', fv=el('rfDiv').value||'all';
  if(fd!=='all') return [fd];
  if(fv!=='all') return DIVS.find(d=>d.id===fv).depts;
  return DIVS.flatMap(d=>d.depts);
}
function reqStaff(dept,srt){
  let staff=PROFILES.filter(p=>p.dept===dept&&!p.auto);
  if(srt==='sen') staff.sort((a,b)=>a.hire.localeCompare(b.hire));
  else{
    const tds=dstr(today);
    const soon=p=>{ const up=REQS.filter(r=>r.sid===p.id&&r.e>=tds).map(r=>r.s).sort(); return up[0]||'9999'; };
    staff.sort((a,b)=>{ const sa=soon(a),sb=soon(b); return sa!==sb?sa.localeCompare(sb):a.hire.localeCompare(b.hire); });
  }
  return staff;
}
function rtag(r){
  const acts=r.status==='pending'
    ?'<div class="ract"><button class="rab ok" onclick="decide(\''+r.id+'\',\'approved\')">✓ Approve</button><button class="rab no" onclick="decide(\''+r.id+'\',\'denied\')">✗ Deny</button></div>'
    :'<div class="ract"><button class="rab" onclick="undoReq(\''+r.id+'\')">↺ Undo</button></div>';
  return '<div class="rtag rt-'+r.status+'">'+r.type+' <span style="font-weight:400;">'+r.s.slice(5)+(r.e!==r.s?'→'+r.e.slice(5):'')+' · '+r.status+'</span></div>'+acts;
}
function reqGridHeader(days,monthMode){
  let h='<thead><tr><th style="text-align:left;padding-left:8px;">Team member</th>';
  days.forEach(dt=>{
    const tdy=dt.getTime()===today.getTime();
    if(monthMode) h+='<th class="mh'+(tdy?' tc':'')+'">'+SD[dt.getDay()][0]+'<br>'+dt.getDate()+'</th>';
    else h+='<th class="'+(tdy?'tc':'')+'">'+SD[dt.getDay()]+'<br><span style="font-weight:400;font-size:11px;">'+MO[dt.getMonth()]+' '+dt.getDate()+'</span></th>';
  });
  return h+'</tr></thead>';
}
function reqGrid(days,monthMode,srt){
  const depts=reqDepts();
  let h=reqGridHeader(days,monthMode)+'<tbody>'; let any=false;
  depts.forEach(dept=>{
    const staff=reqStaff(dept,srt); if(!staff.length)return;
    const dv=divOf(dept); any=true;
    h+='<tr><td class="depthdr" colspan="'+(days.length+1)+'" style="background:'+dv.color+';">'+dept+' <span style="font-weight:400;opacity:.8;">· '+dv.name+'</span></td></tr>';
    staff.forEach(p=>{
      h+='<tr><td class="nc"><div class="ncn">'+p.first+' '+p.last+(p.mgr?' <span style="font-size:10px;color:#534AB7;">MGR</span>':'')+'</div><div class="ncs">Since '+p.hire.slice(0,4)+' · '+tenure(p.hire)+'y</div></td>';
      days.forEach(dt=>{
        const ds=dstr(dt), rq=REQS.filter(r=>r.sid===p.id&&ds>=r.s&&ds<=r.e);
        if(monthMode){
          const we=dt.getDay()===0||dt.getDay()===6, tdy=dt.getTime()===today.getTime();
          if(rq.length){ const r=rq[0]; h+='<td class="mc mq-'+r.status+(tdy?' tdy':'')+'" title="'+p.first+' '+p.last+' · '+r.type+' · '+r.status+'" onclick="cellJump(\''+ds+'\')">'+r.type[0]+'</td>'; }
          else h+='<td class="mc'+(we?' we':'')+(tdy?' tdy':'')+'"></td>';
        } else {
          if(rq.length) h+='<td class="rc">'+rq.map(r=>rtag(r)).join('')+'</td>';
          else h+='<td class="rc" style="background:'+((dt.getDay()===0||dt.getDay()===6)?'#fafaf8':'#fff')+';"></td>';
        }
      });
      h+='</tr>';
    });
  });
  h+='</tbody>'; if(!any) return null; return h;
}

const RLEG='<div style="display:flex;gap:12px;align-items:center;margin:8px 0 0;font-size:11px;color:#555;flex-wrap:wrap;"><span class="stpill st-pending">pending</span><span class="stpill st-approved">approved</span><span class="stpill st-denied">denied</span><span style="color:#888;">Staff rows by department, day columns, today outlined. Monthly cells clickable → daily view.</span></div>';

function reqCard(r){
  const p=prof(r.sid);
  return '<div class="rqcard '+r.status+'"><div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;"><span style="font-weight:500;">'+p.first+' '+p.last+'</span><span style="font-size:11px;color:#888;">'+p.dept+' · since '+p.hire.slice(0,4)+'</span><span class="stpill '+rTypeCls(r.type)+'">'+r.type+'</span><span style="font-family:var(--font-mono);font-size:11px;">'+r.s+(r.e!==r.s?' → '+r.e:'')+'</span><span style="font-size:11px;color:#888;">'+(r.note||'')+'</span><span class="stpill st-'+r.status+'" style="margin-left:auto;">'+r.status+'</span></div><div style="margin-top:6px;display:flex;gap:6px;">'+(r.status==='pending'?'<button class="btn success" onclick="decide(\''+r.id+'\',\'approved\')">Approve</button><button class="btn" style="color:#791F1F;border-color:#e0a5a5;" onclick="decide(\''+r.id+'\',\'denied\')">Deny</button>':'<button class="btn" onclick="undoReq(\''+r.id+'\')">Undo</button>')+'</div></div>';
}

function renderReq(){
  updBadge();
  ['list','day','week','month'].forEach(v=>{ const b=el('vb_'+v); if(b) b.className='btn'+(reqView===v?' vsel':''); });
  if(!el('rqSid').options.length) el('rqSid').innerHTML=PROFILES.filter(p=>!p.auto).map(p=>'<option value="'+p.id+'">'+p.first+' '+p.last+' — '+p.dept+'</option>').join('');
  if(!el('rqS').value){ el('rqS').value=dstr(today); el('rqE').value=dstr(today); }
  const srt=el('rfSort').value||'date', fd=el('rfDept').value||'all', fv=el('rfDiv').value||'all';
  const vis=REQS.filter(r=>{ const p=prof(r.sid); if(!p)return false; if(fv!=='all'&&p.div!==fv)return false; if(fd!=='all'&&p.dept!==fd)return false; return true; });
  const w=el('reqWrap');

  if(reqView==='day'){
    const ds=dstr(dayCur);
    const nav='<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap;"><button class="btn" onclick="dayNav(-1)">←</button><span style="font-weight:500;font-size:13px;">'+SD[dayCur.getDay()]+', '+MO[dayCur.getMonth()]+' '+dayCur.getDate()+', '+dayCur.getFullYear()+'</span><button class="btn" onclick="dayNav(1)">→</button><input type="date" value="'+ds+'" onchange="dayJump(this.value)"></div>';
    const g=reqGrid([new Date(dayCur)],false,srt);
    w.innerHTML=nav+(g?'<div style="overflow-x:auto;"><table class="sg" style="min-width:0;">'+g+'</table></div>'+RLEG:'<div style="color:#888;font-size:12px;padding:20px;text-align:center;">No staff match the current filters.</div>');
    return;
  }
  if(reqView==='week'){
    const days=[]; for(let d=0;d<7;d++) days.push(addD(wkR,d));
    const nav='<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;"><button class="btn" onclick="wkRNav(-1)">←</button><span style="font-weight:500;font-size:13px;">'+MO[wkR.getMonth()]+' '+wkR.getDate()+' – '+MO[addD(wkR,6).getMonth()]+' '+addD(wkR,6).getDate()+', '+addD(wkR,6).getFullYear()+'</span><button class="btn" onclick="wkRNav(1)">→</button></div>';
    const g=reqGrid(days,false,srt);
    w.innerHTML=nav+(g?'<div style="overflow-x:auto;"><table class="sg">'+g+'</table></div>'+RLEG:'<div style="color:#888;font-size:12px;padding:20px;text-align:center;">No staff match the current filters.</div>');
    return;
  }
  if(reqView==='month'){
    const days=[], dim=new Date(calM.getFullYear(),calM.getMonth()+1,0).getDate();
    for(let d=1;d<=dim;d++) days.push(new Date(calM.getFullYear(),calM.getMonth(),d));
    const nav='<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;"><button class="btn" onclick="calNav(-1)">←</button><span style="font-weight:500;font-size:13px;">'+MO[calM.getMonth()]+' '+calM.getFullYear()+'</span><button class="btn" onclick="calNav(1)">→</button><span style="font-size:11px;color:#888;">Click a colored cell to open that day</span></div>';
    const g=reqGrid(days,true,srt);
    w.innerHTML=nav+(g?'<div style="overflow-x:auto;"><table class="sg">'+g+'</table></div>'+RLEG:'<div style="color:#888;font-size:12px;padding:20px;text-align:center;">No staff match the current filters.</div>');
    return;
  }
  // List view
  const bySid={};vis.forEach(r=>{(bySid[r.sid]=bySid[r.sid]||[]).push(r);});
  let people=Object.keys(bySid).map(sid=>{ const rs=bySid[sid].sort((a,b)=>a.s.localeCompare(b.s)); return{sid,rs,soon:rs.filter(r=>r.e>=dstr(today)).map(r=>r.s).sort()[0]||'9999'}; });
  if(srt==='sen') people.sort((a,b)=>prof(a.sid).hire.localeCompare(prof(b.sid).hire));
  else people.sort((a,b)=>a.soon.localeCompare(b.soon));
  if(!people.length){ w.innerHTML='<div style="color:#888;font-size:12px;padding:20px;text-align:center;">No requests match the current filters.</div>'; return; }
  w.innerHTML=people.map(g=>{ const p=prof(g.sid);
    return '<div class="persongrp"><div class="ph"><span>'+p.first+' '+p.last+'</span><span style="font-size:11px;color:#888;font-weight:400;">'+p.dept+' · since '+p.hire.slice(0,4)+' ('+tenure(p.hire)+'y)</span><span style="margin-left:auto;font-size:11px;color:#888;font-weight:400;">'+g.rs.length+' request'+(g.rs.length===1?'':'s')+'</span></div><div style="padding:0 4px 4px;">'+g.rs.map(reqCard).join('')+'</div></div>';}).join('');
}

// ── Statistics ────────────────────────────────────────────────────────────────
function renderStats(){
  const tot=REQS.length, pen=REQS.filter(r=>r.status==='pending').length,
        app=REQS.filter(r=>r.status==='approved').length, den=REQS.filter(r=>r.status==='denied').length;
  const pct=n=>tot?Math.round(n/tot*100):0;
  let h='<div class="statgrid"><div class="statc"><div class="statn">'+tot+'</div><div class="statl">Total requests</div></div><div class="statc"><div class="statn" style="color:#534AB7;">'+pen+'</div><div class="statl">Pending</div></div><div class="statc"><div class="statn" style="color:#27500A;">'+app+'</div><div class="statl">Approved · '+pct(app)+'%</div></div><div class="statc"><div class="statn" style="color:#791F1F;">'+den+'</div><div class="statl">Denied · '+pct(den)+'%</div></div><div class="statc"><div class="statn" style="color:#854F0B;">'+CALLOFFS.length+'</div><div class="statl">Call-offs this week</div></div></div>';
  h+='<div class="seclbl">Requests by type</div>';
  ['VAC','SICK','PER','FMLA'].forEach(t=>{ const n=REQS.filter(r=>r.type===t).length; h+='<div class="barrow"><span class="barl">'+t+'</span><div class="barw"><div class="barf" style="width:'+pct(n)+'%;background:#185FA5;"></div></div><span style="font-family:var(--font-mono);font-size:11px;width:24px;">'+n+'</span></div>'; });
  h+='<div class="seclbl">Outcomes</div>';
  [['Approved',app,'#27500A'],['Pending',pen,'#534AB7'],['Denied',den,'#791F1F']].forEach(x=>{ h+='<div class="barrow"><span class="barl">'+x[0]+'</span><div class="barw"><div class="barf" style="width:'+pct(x[1])+'%;background:'+x[2]+';"></div></div><span style="font-family:var(--font-mono);font-size:11px;width:24px;">'+x[1]+'</span></div>'; });
  h+='<div class="seclbl">Call-off log</div>'+CALLOFFS.map(c=>'<div class="rqcard" style="border-left:4px solid #854F0B;"><span style="font-weight:500;">'+c.n+'</span> <span style="color:#888;font-size:11px;">'+c.d+' · '+c.w+'</span> — '+c.r+'</div>').join('');
  h+='<div class="seclbl">Denied log</div>'+(REQS.filter(r=>r.status==='denied').map(r=>{ const p=prof(r.sid); return '<div class="rqcard denied"><span style="font-weight:500;">'+p.first+' '+p.last+'</span> <span style="font-family:var(--font-mono);font-size:11px;">'+r.s+'</span> · '+r.type+(r.note?' — '+r.note:'')+'</div>'; }).join('')||'<div style="color:#888;font-size:12px;">None</div>');
  el('statsWrap').innerHTML=h;
}

// ── Inventory ─────────────────────────────────────────────────────────────────
function renderInv(){
  let h='<thead><tr><th>Supply item</th><th style="text-align:center;">Stock</th><th style="text-align:center;">Par</th><th style="text-align:center;">Status</th><th style="text-align:center;">Adjust</th></tr></thead><tbody>';
  let cat='';
  SUP.forEach((s,i)=>{
    if(s.cat!==cat){ cat=s.cat; h+='<tr class="cat-row"><td colspan="5">'+cat+'</td></tr>'; }
    const low=s.stock<s.par*0.8;
    h+='<tr><td>'+s.n+'</td><td style="text-align:center;font-family:var(--font-mono);">'+s.stock+'</td><td style="text-align:center;font-family:var(--font-mono);color:#888;">'+s.par+'</td><td style="text-align:center;"><span class="pill '+(low?'p-low':'p-ok')+'">'+(low?'LOW':'OK')+'</span></td><td style="text-align:center;white-space:nowrap;"><button class="adj" onclick="adjS('+i+',-1)">−</button> <button class="adj" onclick="adjS('+i+',1)">+</button></td></tr>';
  });
  el('supTbl').innerHTML=h+'</tbody>';
  el('eqTbl').innerHTML='<thead><tr><th>Equipment</th><th style="text-align:center;">Condition</th><th>Assigned to</th><th>Status</th></tr></thead><tbody>'+EQ.map(q=>'<tr><td>'+q.n+'</td><td style="text-align:center;"><span class="pill p-'+q.cond+'">'+q.cond+'</span></td><td>'+q.asg+'</td><td>'+q.st+'</td></tr>').join('')+'</tbody>';
}
window.adjS=function(i,d){ SUP[i].stock=Math.max(0,SUP[i].stock+d); renderInv(); schedSave(); };

// ── Profiles ──────────────────────────────────────────────────────────────────
function renderProf(){
  const f=el('pfDept');
  if(!f.options.length) f.innerHTML='<option value="all">All departments</option>'+DIVS.flatMap(d=>d.depts).map(d=>'<option>'+d+'</option>').join('');
  const v=f.value||'all';
  const list=PROFILES.filter(p=>v==='all'||p.dept===v).sort((a,b)=>a.hire.localeCompare(b.hire));
  el('profWrap').innerHTML=list.map(p=>{
    const dv=DIVS.find(d=>d.id===p.div);
    return '<div class="pcard"><div style="display:flex;gap:10px;align-items:center;margin-bottom:8px;"><div class="av">'+(p.first[0]+(p.last[0]||'')).toUpperCase()+'</div><div><div style="font-weight:500;font-size:13px;">'+p.first+' '+p.last+(p.mgr?' <span style="font-size:10px;color:#534AB7;">MGR</span>':'')+(p.auto?' <span style="font-size:10px;color:#854F0B;">Auto-added RA</span>':'')+'</div><div style="font-size:11px;color:#888;">'+p.dept+' · '+dv.name+'</div></div></div><div style="font-size:11px;color:#555;line-height:1.7;">Hired '+p.hire+' · '+tenure(p.hire)+'y<br>'+p.phone+'<br>'+p.email+'</div><div style="display:flex;gap:6px;margin-top:8px;"><span class="balchip">VAC '+p.vU+'/'+p.vT+'</span><span class="balchip">SICK '+p.sU+'/'+p.sT+'</span></div></div>';
  }).join('');
}

// ── Housekeeping ──────────────────────────────────────────────────────────────
function autoCreateRAs(){
  let made=0;
  HK_FLOORS.forEach(r=>{
    const nm=(r.ra||'').trim(); if(!nm||NO_PROF.includes(nm)||findByName(nm))return;
    const parts=nm.split(/\s+/), off=OFF_RA.includes(nm);
    PROFILES.push({id:'hk'+(hkN++),first:parts[0],last:parts.slice(1).join(' ')||'—',dept:'Housekeeping',div:'rooms',hire:dstr(today),ps:480,pe:990,offs:off?[0,1,2,3,4,5,6]:[],mgr:false,auto:true,vU:0,vT:15,sU:0,sT:10,phone:'—',email:'—'});
    made++;
  });
  return made;
}
function getHKDate(){ const v=el('hkDate').value; return v?fromDs(v):new Date(today); }
function workingHK(p,ds){ const c=getD(p.id,ds); return !c.pto&&c.s!=null; }

function renderHK(){
  const ds=dstr(getHKDate());
  let h='<thead><tr><th rowspan="2">Floor</th><th rowspan="2">Room attendant</th><th rowspan="2">In</th><th colspan="3">Daily assignment</th><th rowspan="2">Dropped rooms</th><th rowspan="2">Out</th></tr><tr><th class="sub">Credits</th><th class="sub">Check outs</th><th class="sub">Double beds</th></tr></thead><tbody>';
  const SG=['TD','Floaters','Floater','Agency'];
  HK_FLOORS.forEach((r,i)=>{
    const sect=i>0&&HK_FLOORS[i-1].floor!==r.floor&&SG.includes(r.floor)&&!SG.includes(HK_FLOORS[i-1].floor);
    if(sect) h+='<tr class="section-row"><td colspan="8">'+r.floor+'</td></tr>';
    const p=findByName(r.ra), working=p?workingHK(p,ds):false, noP=r.ra&&r.ra.trim()&&!p;
    const cls=p?(working?'hk-w':'hk-o'):'', dis=p&&!working?'disabled':'';
    let chip='';
    if(p&&working) chip='<span class="chip chip-working" title="Scheduled '+fmtT(getD(p.id,ds).s)+'–'+fmtT(getD(p.id,ds).e)+'">●</span>';
    else if(p) chip='<span class="chip chip-off" title="Not scheduled">●</span>';
    else if(noP) chip='<span class="chip chip-noprofile" title="No matching profile">●</span>';
    h+='<tr class="'+cls+'">'
      +'<td class="floor-cell"><input class="ra-inp" style="text-align:center;font-weight:500;" value="'+r.floor+'" onchange="updHK('+i+',\'floor\',this.value)"></td>'
      +'<td style="min-width:130px;"><span style="display:flex;align-items:center;gap:4px;"><input class="ra-inp" style="flex:1;" value="'+r.ra+'" placeholder="—" onchange="updHK('+i+',\'ra\',this.value);renderHK();">'+chip+'</span></td>'
      +'<td><input class="ti-hk" value="'+r.in+'" placeholder="--:--" onchange="updHK('+i+',\'in\',this.value)" '+dis+'></td>'
      +'<td><input class="ni-hk" value="'+r.credits+'" onchange="updHK('+i+',\'credits\',this.value)" '+dis+'></td>'
      +'<td><input class="ni-hk" value="'+r.co+'" onchange="updHK('+i+',\'co\',this.value)" '+dis+'></td>'
      +'<td><input class="ni-hk" value="'+r.db+'" onchange="updHK('+i+',\'db\',this.value)" '+dis+'></td>'
      +'<td><input class="ni-hk" value="'+r.dropped+'" onchange="updHK('+i+',\'dropped\',this.value)" '+dis+'></td>'
      +'<td><input class="ti-hk" value="'+r.out+'" placeholder="--:--" onchange="updHK('+i+',\'out\',this.value)" '+dis+'></td></tr>';
  });
  const sum=f=>HK_FLOORS.reduce((s,r)=>s+(parseFloat(r[f])||0),0);
  h+='<tr class="tot-row"><td colspan="3" style="text-align:right;">Totals →</td><td>'+(sum('credits')||'')+'</td><td>'+(sum('co')||'')+'</td><td>'+(sum('db')||'')+'</td><td colspan="2"></td></tr></tbody>';
  el('hkTbl').innerHTML=h;
  renderRoles(); renderSum();
}
window.updHK=function(i,f,v){ HK_FLOORS[i][f]=v; schedSave(); if(['credits','co','db'].includes(f)) renderHK(); };
window.addFloorRow=function(){ HK_FLOORS.push({floor:'New',ra:'',in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''}); renderHK(); schedSave(); };

function renderRoles(){
  el('rolesPanel').innerHTML=Object.keys(HK_ROLES).map(role=>{ const key=role.replace(/'/g,"\\'");
    return '<div style="border-bottom:1px solid #eee;"><div class="hk-role-title">'+role+'</div>'
      +HK_ROLES[role].map((p,i)=>'<div class="hk-role-row"><span class="hk-role-tag">'+(p.tag?p.tag+':':'')+'</span><input class="hk-role-inp" value="'+p.name+'" placeholder="—" onchange="updRole(\''+key+'\','+i+',this.value)"></div>').join('')
      +'<div style="padding:3px 12px 6px;"><button class="btn" style="font-size:11px;padding:1px 6px;" onclick="addRole(\''+key+'\')">+ add</button></div></div>'; }).join('');
}
window.updRole=function(r,i,v){ HK_ROLES[r][i].name=v; schedSave(); };
window.addRole=function(r){ HK_ROLES[r].push({tag:'',name:''}); renderRoles(); schedSave(); };

function renderSum(){
  el('sumBody').innerHTML=Object.keys(HK_SUMMARY).map(m=>{ const s=HK_SUMMARY[m]; const b=parseFloat(s.before),c=parseFloat(s.current); const has=s.before!==''&&s.current!==''; const d=has?c-b:0; const cls=d>0?'pos':d<0?'neg':'zero';
    return '<tr><td class="lbl">'+m+'</td><td><input class="sum-inp" value="'+s.before+'" onchange="updSum(\''+m+'\',\'before\',this.value)"></td><td><input class="sum-inp" value="'+s.current+'" onchange="updSum(\''+m+'\',\'current\',this.value)"></td><td class="sum-diff '+cls+'">'+(has?((d>0?'+':'')+Math.round(d)):'—')+'</td><td><input class="sum-inp" value="'+s.traces+'" onchange="updSum(\''+m+'\',\'traces\',this.value)"></td><td><input class="sum-inp" value="'+s.rooms+'" onchange="updSum(\''+m+'\',\'rooms\',this.value)"></td></tr>'; }).join('');
}
window.updSum=function(m,f,v){ HK_SUMMARY[m][f]=v; renderSum(); schedSave(); };

// ── Assignments ───────────────────────────────────────────────────────────────
let curRole='Room attendants';
function floorSec(lbl){ const m=lbl.match(/^(\d+)th \((A|B)\)$/); return m?{fl:+m[1],sec:m[2]}:null; }
function flagsFor(fl,sec){ return FLAGS.filter(f=>Math.floor(f.room/100)===fl&&((f.room%100)>=50?'B':'A')===sec); }
function flagHTML(f){
  if(f.type==='vip') return '<span class="vip v'+f.tier+'">VIP '+f.tier+'</span> <span style="font-family:var(--font-mono);font-weight:500;">'+f.room+'</span> — '+f.txt;
  const tg={trace:'tg-trace',oos:'tg-oos',req:'tg-req',note:'tg-note'}[f.type];
  const lb={trace:'Trace',oos:'OOS/OOO',req:'Request',note:'Note'}[f.type];
  return '<span class="tagp '+tg+'">'+lb+'</span> <span style="font-family:var(--font-mono);font-weight:500;">'+f.room+'</span> — '+f.txt;
}
function renderAssign(){
  const roles=['Room attendants','Housepersons','Public areas','Supervisors','Managers'];
  const counts={'Room attendants':HK_FLOORS.filter(r=>r.ra.trim()).length,'Housepersons':HK_ROLES['Houseman'].length,'Public areas':HK_ROLES['Public areas'].length,'Supervisors':HK_ROLES['Supervisors'].length,'Managers':HK_ROLES['Manager on duty'].length};
  el('roleTabs').innerHTML=roles.map(r=>'<div class="sub-tab'+(r===curRole?' active':'')+'" onclick="setRole(\''+r+'\')">'+r+' <span class="badge">'+counts[r]+'</span></div>').join('');
  el('asBadge').textContent=FLAGS.length;
  const ds=dstr(getHKDate()), w=el('asWrap');
  if(curRole==='Room attendants'){
    w.innerHTML=HK_FLOORS.filter(r=>r.ra.trim()).map(r=>{
      const fs=floorSec(r.floor), p=findByName(r.ra), working=p?workingHK(p,ds):false, off=p&&!working;
      const items=fs?flagsFor(fs.fl,fs.sec):[];
      return '<div class="as-card'+(off?' dim':'')+'"><div class="as-hdr"><span class="as-floor">'+r.floor+'</span><span class="as-name">'+r.ra+'</span>'+(off?'<span class="chip chip-off">OFF</span>':working?'<span class="chip chip-working">Working</span>':'<span class="chip chip-noprofile">No profile</span>')+'<span style="margin-left:auto;font-size:11px;color:#888;">'+items.length+' flagged room'+(items.length===1?'':'s')+'</span></div>'+(items.length?items.map(f=>'<div class="as-item">'+flagHTML(f)+'</div>').join(''):'<div class="as-item" style="color:#aaa;">No VIPs, traces, or OOS rooms in this section</div>')+'</div>';}).join('');
  }else if(curRole==='Managers'){
    const vip=FLAGS.filter(f=>f.type==='vip').length, tr=FLAGS.filter(f=>f.type==='trace').length, oo=FLAGS.filter(f=>f.type==='oos').length;
    const totP=Object.values(PROJECTS).reduce((n,a)=>n+a.length,0), doneP=Object.keys(DONE).filter(k=>DONE[k]).length;
    w.innerHTML=HK_ROLES['Manager on duty'].map(m=>'<div class="as-card"><div class="as-hdr"><span class="as-name">'+m.name+'</span><span class="chip chip-working">MOD</span></div><div class="as-item"><span class="tagp tg-trace">Overview</span> '+vip+' VIP arrivals · '+tr+' traces · '+oo+' OOS/OOO rooms · '+doneP+' of '+totP+' projects complete</div><div class="as-item"><span class="tagp tg-req">Focus</span> Walk VIP rooms before the 2 PM arrival window; confirm OOS board with engineering</div></div>').join('');
  }else{
    const src=curRole==='Housepersons'?'Housepersons':curRole;
    const staff=curRole==='Housepersons'?HK_ROLES['Houseman']:HK_ROLES[curRole];
    const projs=PROJECTS[src];
    w.innerHTML='<div class="as-card"><div class="as-hdr"><span class="as-name">'+curRole+' — today\'s projects</span><span style="margin-left:auto;font-size:11px;color:#888;">'+staff.map(s=>(s.tag?s.tag+': ':'')+s.name).join(' · ')+'</span></div>'+projs.map((p,i)=>{ const k=src+'_'+i; return '<label class="as-item" style="cursor:pointer;align-items:center;"><input type="checkbox" style="width:auto;height:auto;margin:0;" '+(DONE[k]?'checked':'')+' onchange="togDone(\''+k+'\')"><span style="'+(DONE[k]?'text-decoration:line-through;color:#aaa;':'')+'">'+p.t+'</span><span style="font-size:11px;color:#888;">'+p.loc+'</span><span class="pri pr-'+p.pri+'">'+p.pri+'</span></label>'; }).join('')+'</div>';
  }
}
window.setRole =r=>{ curRole=r; renderAssign(); };
window.togDone =k=>{ DONE[k]=!DONE[k]; renderAssign(); schedSave(); };

// ── Boot ──────────────────────────────────────────────────────────────────────
(async function init(){
  if(el('hkDate')) el('hkDate').value=dstr(today);
  const loaded = await loadFromStorage();
  if(!loaded){ seedReqs(); setDot('saved','New unified project'); }
  const made=autoCreateRAs();
  if(made>0){
    const b=el('autoBanner');
    if(b){ b.style.display='block'; b.innerHTML='✓ <strong style="font-weight:500;">'+made+' room attendants</strong> from the roster now exist as Housekeeping staff in this project (08:00–16:30 default). Karen H and Karolay R are off; Johana J (agency) has no profile.'; }
  }
  if(el('rfDiv')) el('rfDiv').innerHTML='<option value="all">All divisions</option>'+DIVS.map(d=>'<option value="'+d.id+'">'+d.name+'</option>').join('');
  if(el('rfDept')) el('rfDept').innerHTML='<option value="all">All departments</option>'+DIVS.flatMap(d=>d.depts).map(d=>'<option>'+d+'</option>').join('');
  renderReq(); renderSched(); renderStats(); renderInv(); renderProf(); renderHK(); renderAssign();
  if(el('hkDate')) el('hkDate').addEventListener('change',()=>{ renderHK(); schedSave(); });
  if(!loaded) hopSave();
})();
