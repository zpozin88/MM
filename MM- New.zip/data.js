// ─── DATA ────────────────────────────────────────────────────────────────────
const KEY = 'hotel_ops_pro_v39';

// Divisions and departments
const DIVS = [
  { id:'rooms', name:'Rooms division',   color:'#185FA5',
    depts:['Front Desk','Housekeeping','Concierge','Valet & Bell'] },
  { id:'fb',    name:'Food and beverage',color:'#0F6E56',
    depts:['Restaurant','Banquet & Events','Bar & Lounge','Room Service'] },
  { id:'sup',   name:'Support services', color:'#534AB7',
    depts:['Maintenance','Human Resources','Management','Security'] }
];

// Quick-fill times per department (minutes from midnight) — editable via Settings
let QUICK = {
  'Front Desk':     [420,  870, 1380],
  'Housekeeping':   [480,  540,  600],
  'Concierge':      [420,  600,  840],
  'Valet & Bell':   [360,  840,  900],
  'Restaurant':     [360,  600,  840],
  'Banquet & Events':[480, 600,  840],
  'Bar & Lounge':   [720,  960, 1200],
  'Room Service':   [360,  840,  900],
  'Maintenance':    [420,  480,  900],
  'Human Resources':[480,  510,  540],
  'Management':     [480,  510,  540],
  'Security':       [420,  900, 1380]
};

// Coverage needs (7 days) per department
let NEEDS = {};
DIVS.forEach(d => d.depts.forEach(dp => NEEDS[dp] = [2,2,2,2,2,2,2]));
NEEDS['Front Desk']  = [2,3,3,3,3,3,2];
NEEDS['Housekeeping']= [2,3,3,3,3,2,2];

// Staff profiles
function P(id,f,l,dept,div,hire,ps,pe,offs,mgr){
  return { id, first:f, last:l, dept, div, hire, ps, pe,
    offs:offs||[], mgr:!!mgr,
    vU:6, vT:15, sU:2, sT:10,
    phone:'(305) 555-01'+id.replace(/\D/g,'').padStart(2,'0'),
    email:(f+'.'+l).toLowerCase().replace(/\s/g,'')+'@hotel.com' };
}
let PROFILES = [
  P('s1','Maria','G','Front Desk','rooms','2019-03-12',420,930,[2,3]),
  P('s2','James','T','Front Desk','rooms','2021-07-01',870,1380,[0,6]),
  P('s3','Priya','K','Front Desk','rooms','2022-01-15',420,930,[1,2]),
  P('s4','Carlos','M','Housekeeping','rooms','2017-05-20',480,990,[0,6]),
  P('s5','Linda','W','Housekeeping','rooms','2020-09-08',480,990,[2,3]),
  P('s6','Fatima','H','Housekeeping','rooms','2023-04-02',540,1050,[4,5]),
  P('s8','Leo','V','Concierge','rooms','2018-11-30',420,930,[0,1]),
  P('s7','Omar','S','Valet & Bell','rooms','2021-03-18',360,870,[3,4]),
  P('s9','Nina','A','Valet & Bell','rooms','2023-02-14',840,1350,[1,2]),
  P('s10','Sophie','L','Restaurant','fb','2019-08-22',360,870,[2,3]),
  P('s11','Diego','R','Restaurant','fb','2022-05-10',840,1350,[0,1]),
  P('s12','Rosa','P','Banquet & Events','fb','2016-04-03',480,990,[0,6]),
  P('s13','Marc','D','Bar & Lounge','fb','2021-10-11',960,1470,[1,2]),
  P('s14','Amy','C','Room Service','fb','2022-06-30',360,870,[3,4]),
  P('s15','Kevin','O','Maintenance','sup','2015-12-01',420,930,[0,6]),
  P('s16','Raj','P','Maintenance','sup','2019-06-15',480,990,[2,3]),
  P('s18','Sara','J','Human Resources','sup','2018-03-26',480,990,[0,6],1),
  P('m1','Chen','W','Management','sup','2014-08-18',480,990,[0,6],1),
  P('m2','Diane','K','Management','sup','2016-09-05',510,1020,[0,6],1),
  P('s19','Tony','M','Security','sup','2018-07-09',420,930,[1,2]),
  P('s17','Frank','B','Security','sup','2020-01-20',900,1410,[3,4])
];

// Seeded request-off data (overwritten on load from storage)
let REQS = [];
let CD = {}, PUB = {};

// Housekeeping roster
let HK_FLOORS = [
  {floor:'8th (A)', ra:'Astrid T',           in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'8th (B)', ra:'',                   in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'9th (A)', ra:'Maria G Irausquin',  in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'9th (B)', ra:'',                   in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'10th (A)',ra:'',                   in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'10th (B)',ra:'Eunice de Leon',     in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'11th (A)',ra:'Pilar Sierra',       in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'11th (B)',ra:'Karen H',            in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'12th (A)',ra:'Cheyla Soriano',     in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'12th (B)',ra:'Rosa Castillo',      in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'14th (A)',ra:'Lamia Iddir',        in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'14th (B)',ra:'Cindy H',            in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'15th (A)',ra:'Tania Maceda',       in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'15th (B)',ra:'Janeth',             in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'16th (A)',ra:'Lissetta L',         in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'16th (B)',ra:'Karolay R',          in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'17th (A)',ra:'Gaelle Cesar',       in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'17th (B)',ra:'Irma Z',             in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'18th (A)',ra:'Teresita Fabregas',  in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'18th (B)',ra:'',                   in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'19th (A)',ra:'Luisa Mendoza',      in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'19th (B)',ra:'Alcira J',           in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'TD',      ra:'Esmeralda TD',       in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'TD',      ra:'Jocelyn',            in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'Floaters',ra:'Vilma Acuna',        in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'Floater', ra:'Mariolys A.',        in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'Agency',  ra:'Johana J Xclusive', in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''},
  {floor:'Agency',  ra:'',                   in:'',credits:'',co:'',db:'',mid:'',dropped:'',out:''}
];

let HK_ROLES = {
  'Public areas':       [{tag:'AM',    name:'Hellen'},   {tag:'AM/Mid',name:'Rafaela'},
                         {tag:'Mid/PM',name:'Jocelyne'}, {tag:'PM',    name:'Mayra'},
                         {tag:'PM',    name:'Elizabeth'}],
  'Supervisors':        [{tag:'',name:'Dayanis Gumbs'}, {tag:'',name:'Maria Zambrano'},
                         {tag:'',name:'Frayne Sandoval'},{tag:'',name:'Sorayda Castrillo'}],
  'Uniform attendants': [{tag:'AM',name:'Dunia Hands'}, {tag:'PM',name:'Vilma Acuna'}],
  'Manager on duty':    [{tag:'',name:'Oscar Olivas'},  {tag:'',name:'Ernesto Cano'}],
  'Houseman':           [{tag:'PM',name:'Jose Xclusive'},{tag:'AM',name:'Osman'},
                         {tag:'AM',name:'Teresita'},     {tag:'',  name:'Sergio Xclusive'},
                         {tag:'',  name:'Jesus Xclusive'},{tag:'PM',name:'Claudia'},
                         {tag:'PM',name:'Roberto'}]
};

let HK_SUMMARY = {
  'Rooms total': {before:'182',current:'182',traces:'7',rooms:'5'},
  'Departures':  {before:'46', current:'52', traces:'', rooms:''},
  'Stayovers':   {before:'118',current:'109',traces:'', rooms:''},
  'Arrivals':    {before:'44', current:'57', traces:'', rooms:''},
  'RA scheduled':{before:'20', current:'19', traces:'', rooms:''},
  'Total credits':{before:'268',current:'274',traces:'',rooms:''}
};

// Inventory
let SUP = [
  {cat:'Linens',    n:'Bath towels',              stock:340,par:400},
  {cat:'Linens',    n:'Hand towels',              stock:295,par:300},
  {cat:'Linens',    n:'Washcloths',               stock:180,par:350},
  {cat:'Linens',    n:'King sheet sets',          stock:96, par:120},
  {cat:'Linens',    n:'Queen sheet sets',         stock:142,par:140},
  {cat:'Linens',    n:'Pillowcases',              stock:410,par:500},
  {cat:'Amenities', n:'Shampoo (units)',           stock:520,par:600},
  {cat:'Amenities', n:'Soap bars',                stock:230,par:600},
  {cat:'Amenities', n:'Coffee pods',              stock:780,par:800},
  {cat:'Cleaning',  n:'All-purpose cleaner (gal)',stock:14, par:20},
  {cat:'Cleaning',  n:'Glass cleaner (gal)',      stock:9,  par:12}
];
let EQ = [
  {n:'Vacuum — Karcher 1',    cond:'good',  asg:'8th–10th cart', st:'In use'},
  {n:'Vacuum — Karcher 2',    cond:'good',  asg:'11th–12th cart',st:'In use'},
  {n:'Vacuum — Karcher 3',    cond:'fair',  asg:'14th–15th cart',st:'In use'},
  {n:'Vacuum — Karcher 4',    cond:'repair',asg:'—',             st:'At vendor'},
  {n:'Housekeeping cart A',   cond:'good',  asg:'Astrid T',      st:'In use'},
  {n:'Housekeeping cart B',   cond:'fair',  asg:'Pilar Sierra',  st:'In use'},
  {n:'Radios (set of 12)',    cond:'good',  asg:'HK office',     st:'Charged'},
  {n:'Carpet extractor',      cond:'fair',  asg:'Storage B2',    st:'Available'},
  {n:'Floor buffer',          cond:'good',  asg:'Public areas',  st:'In use'}
];
let DONE = {};

// HK assignment flags
const FLAGS = [
  {room:801, type:'trace',txt:'Extra pillows requested'},
  {room:802, type:'req',  txt:'Hypoallergenic bedding'},
  {room:803, type:'oos',  txt:'Leak repair — out of service'},
  {room:804, type:'vip',  tier:1,txt:'Mr. Whitfield — 25th anniversary'},
  {room:804, type:'note', txt:'Prior noise complaint — follow up'},
  {room:806, type:'vip',  tier:3,txt:'Repeat guest'},
  {room:903, type:'vip',  tier:2,txt:'Suite upgrade'},
  {room:1052,type:'trace',txt:'No entry before 10 AM'},
  {room:1053,type:'oos',  txt:'Renovation — out of order'},
  {room:1102,type:'vip',  tier:1,txt:'Ms. Alvarez — board member, DND until 11 AM'},
  {room:1152,type:'oos',  txt:'Carpet replacement'},
  {room:1203,type:'vip',  tier:4,txt:'Loyalty elite'},
  {room:1406,type:'trace',txt:'Crib requested'},
  {room:1452,type:'note', txt:'Firm mattress topper on arrival'},
  {room:1504,type:'vip',  tier:2,txt:'Press stay'},
  {room:1553,type:'req',  txt:'Extra towels x4'},
  {room:1604,type:'oos',  txt:'AC repair'},
  {room:1701,type:'trace',txt:'Verify AC operation'},
  {room:1755,type:'req',  txt:'Connecting rooms setup'},
  {room:1902,type:'vip',  tier:5,txt:'Return guest'},
  {room:1907,type:'oos',  txt:'Water damage — out of order'}
];
const PROJECTS = {
  'Housepersons':[
    {t:'Restock linen closets floors 8–12',   loc:'Service corridors',pri:'high'},
    {t:'Deliver crib to 1406',                loc:'14th floor',       pri:'high'},
    {t:'Deliver connecting-room kit to 1755', loc:'17th floor',       pri:'med'},
    {t:'Mattress rotation — 17th floor',      loc:'17th floor',       pri:'med'},
    {t:'Clear service landings of trash',     loc:'All floors',       pri:'low'}
  ],
  'Public areas':[
    {t:'Lobby marble polish',             loc:'Lobby',          pri:'high'},
    {t:'Pool deck reset',                 loc:'Pool',           pri:'med'},
    {t:'Elevator track detail',           loc:'Elevators A–D',  pri:'med'},
    {t:'Gym mirrors and equipment wipe-down',loc:'Fitness center',pri:'low'}
  ],
  'Supervisors':[
    {t:'Inspect VIP arrivals — 804, 1102, 1504',loc:'8th / 11th / 15th',pri:'high'},
    {t:'Verify OOS board matches PMS',          loc:'HK office',        pri:'high'},
    {t:'AM board briefing',                     loc:'HK office',        pri:'med'},
    {t:'Spot-check 10 stayovers',               loc:'Random floors',    pri:'med'}
  ]
};

const CALLOFFS = [
  {n:'Linda W', d:'Housekeeping',  r:'Flu',              w:'Tue'},
  {n:'Marc D',  d:'Bar & Lounge',  r:'No-show',          w:'Fri'},
  {n:'Nina A',  d:'Valet & Bell',  r:'Family emergency', w:'Sat'}
];

const OFF_RA  = ['Karen H','Karolay R'];
const NO_PROF = ['Johana J Xclusive'];
let hkN = 1;