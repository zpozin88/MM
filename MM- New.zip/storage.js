// ─── storage.js ──────────────────────────────────────────────────────────────
// Save / load layer for Hotel Ops Pro
//
// Uses localStorage so the app works in any browser —
// locally, on GitHub Pages, or any static host.
// ─────────────────────────────────────────────────────────────────────────────

window.storage = {
  async get(key) {
    const value = localStorage.getItem(key);
    return value ? { key, value } : null;
  },
  async set(key, value) {
    try {
      localStorage.setItem(key, value);
      return { key, value };
    } catch (e) {
      console.error('localStorage write failed:', e);
      return null;
    }
  },
  async delete(key) {
    localStorage.removeItem(key);
    return { key, deleted: true };
  }
};

// ─── Save / load helpers ──────────────────────────────────────────────────────
let _saveTimer = null;

function setDot(state, message) {
  const dot = document.getElementById('hopDot');
  const status = document.getElementById('hopStatus');
  if (dot) dot.className = 'save-dot ' + state;
  if (status) status.textContent = message;
}

async function hopSave(manual) {
  setDot('saving', 'Saving…');
  try {
    const hkDateEl = document.getElementById('hkDate');
    const payload = {
      v: 43,
      at: new Date().toISOString(),
      CD, REQS, NEEDS, PUB, QUICK,
      HK_FLOORS, HK_ROLES, HK_SUMMARY,
      SUP, EQ, DONE,
      hkDate: hkDateEl ? hkDateEl.value : ''
    };
    const result = await window.storage.set(KEY, JSON.stringify(payload));
    if (result) {
      setDot('saved', 'All changes saved');
      const last = document.getElementById('hopLast');
      if (last) last.textContent = 'Last saved ' +
        new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else {
      setDot('error', 'Save failed');
    }
  } catch (e) {
    setDot('error', 'Save error: ' + e.message);
    console.error('hopSave error:', e);
  }
}

function schedSave() {
  if (_saveTimer) clearTimeout(_saveTimer);
  setDot('saving', 'Unsaved changes');
  _saveTimer = setTimeout(() => hopSave(), 2000);
}

async function loadFromStorage() {
  try {
    const result = await window.storage.get(KEY);
    if (!result || !result.value) return false;
    const j = JSON.parse(result.value);
    if (j.CD)         CD         = j.CD;
    if (j.REQS)       REQS       = j.REQS;
    if (j.NEEDS)      NEEDS      = Object.assign(NEEDS, j.NEEDS);
    if (j.PUB)        PUB        = j.PUB;
    if (j.QUICK)      QUICK      = Object.assign(QUICK, j.QUICK);
    if (j.HK_FLOORS)  HK_FLOORS  = j.HK_FLOORS;
    if (j.HK_ROLES)   HK_ROLES   = j.HK_ROLES;
    if (j.HK_SUMMARY) HK_SUMMARY = j.HK_SUMMARY;
    if (j.SUP)        SUP        = j.SUP;
    if (j.EQ)         EQ         = j.EQ;
    if (j.DONE)       DONE       = j.DONE;
    const hkDateEl = document.getElementById('hkDate');
    if (j.hkDate && hkDateEl) hkDateEl.value = j.hkDate;
    return true;
  } catch (e) {
    console.warn('loadFromStorage failed:', e);
    return false;
  }
}
