// ─── UTILITIES ───────────────────────────────────────────────────────────────
const MO = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const SD = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

function el(i){ return document.getElementById(i); }
function pad(n){ return String(n).padStart(2,'0'); }
function dstr(d){ return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate()); }
function fromDs(s){
  const [a,b,c] = s.split('-').map(Number);
  const d = new Date(a,b-1,c); d.setHours(0,0,0,0); return d;
}
function addD(d,n){ const r=new Date(d); r.setDate(r.getDate()+n); return r; }
function sunday(d){ const r=new Date(d); r.setHours(0,0,0,0); r.setDate(r.getDate()-r.getDay()); return r; }
function fmtT(m){
  if(m==null)return'';
  let h=Math.floor(m/60), mi=m%60;
  const ap=h>=12?'p':'a'; let h12=h%12; if(h12===0)h12=12;
  return h12+':'+pad(mi)+ap;
}
function parseT(raw){
  if(!raw||!raw.trim())return null;
  let s=raw.trim().toLowerCase(); let ap=null;
  if(/[ap]m?$/.test(s)){ ap=s.includes('p')?'p':'a'; s=s.replace(/[apm\s]/g,''); }
  let h,mi=0;
  if(s.includes(':')){ const p=s.split(':'); h=parseInt(p[0]); mi=parseInt(p[1])||0; }
  else{
    const n=s.replace(/\D/g,''); if(!n)return null;
    if(n.length<=2) h=parseInt(n);
    else if(n.length===3){ h=parseInt(n[0]); mi=parseInt(n.slice(1)); }
    else{ h=parseInt(n.slice(0,2)); mi=parseInt(n.slice(2)); }
  }
  if(isNaN(h)||h>23||mi>59)return null;
  if(ap==='p'&&h<12)h+=12; if(ap==='a'&&h===12)h=0;
  if(!ap&&h>=1&&h<=6)h+=12;
  return h*60+mi;
}
function divOf(dept){ return DIVS.find(d=>d.depts.includes(dept)); }
function prof(sid){ return PROFILES.find(p=>p.id===sid); }
function norm(s){ return (s||'').toLowerCase().replace(/[^a-z]/g,''); }
function findByName(name){
  const n=norm(name); if(!n)return null;
  return PROFILES.find(p=>norm(p.first+p.last)===n)||null;
}
function tenure(h){ return Math.max(0,Math.floor((today-fromDs(h))/31557600000)); }
function hrsOf(c){
  if(!c||c.pto) return c&&c.pto==='REMOTE'?8:0;
  let m=0;
  if(c.s!=null&&c.e!=null) m+=c.e-c.s;
  if(c.s2!=null&&c.e2!=null) m+=c.e2-c.s2;
  if(m<=0)return 0;
  return Math.max(0,(m-30)/60);
}
const today = new Date(); today.setHours(0,0,0,0);