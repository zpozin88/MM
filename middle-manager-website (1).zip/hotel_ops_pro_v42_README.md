# Hotel Ops Pro — v42

A browser-based hotel operations app covering scheduling, request-offs, inventory, profiles, and housekeeping.

## Files

| File | Purpose |
|------|---------|
| `index.html` | HTML shell — page structure, all tab markup |
| `styles.css` | All styles (CSS variables, layout, component classes) |
| `data.js` | Static seed data: staff, QUICK times, inventory, HK roster, FLAGS |
| `utils.js` | Pure helper functions: date math, time parser/formatter, name lookup |
| `storage.js` | Save/load layer — wraps Claude storage API or localStorage |
| `app.js` | All render functions and event handlers |
| `README.md` | This file |

## Running locally (outside Claude)

1. Open `storage.js` and uncomment the `localStorage` shim block (lines 9–13).
2. Open `index.html` directly in a browser — all files are loaded via `<script src>` and `<link rel="stylesheet">`.
3. No build step, no npm, no bundler required.

## Running inside Claude

Load all six files into a single Claude artifact in this order:
`data.js` → `utils.js` → `storage.js` → `app.js`, with `styles.css` in a `<style>` tag and the HTML inline.
The Claude artifact storage API (`window.storage`) provides cross-session persistence automatically.

## Editing guide

### Add a staff member
Edit the `PROFILES` array in `data.js`. Use the `P()` helper:
```js
P('s99', 'Jane', 'D', 'Front Desk', 'rooms', '2024-01-01', 480, 990, [0,6])
//  id    first  last  department    division  hire-date    start end  days-off
```
Day-off values: 0=Sun, 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat.

### Change quick-fill buttons for a department
Edit the `QUICK` object in `data.js`. Values are minutes from midnight:
- 420 = 7:00 AM · 480 = 8:00 AM · 870 = 2:30 PM · 1380 = 11:00 PM

### Add a new department
1. Add the department name to the right division's `depts` array in `DIVS` (`data.js`).
2. Add its `QUICK` entry.
3. Its `NEEDS` row is auto-seeded to `[2,2,2,2,2,2,2]`.

### Change colors
CSS variables are in `styles.css` under `:root`. The division colors are in `DIVS[].color` inside `data.js`.

### HK roster — add a room attendant
Add a row to `HK_FLOORS` in `data.js`. The app auto-creates a Housekeeping profile for any name that doesn't already have one.

### Storage key
All data is saved under the key `hotel_ops_pro_v39`. Change `KEY` in `data.js` to start fresh.

## Architecture notes

- **No framework, no build step** — vanilla HTML/CSS/JS.
- All render functions are top-level globals in `app.js` (e.g. `renderSched()`, `renderHK()`).
- Inline `onclick` handlers call those globals directly from the HTML attributes.
- Storage is a simple key-value JSON blob — the entire app state in one object.
- `schedSave()` debounces saves by 2 seconds; `hopSave(true)` saves immediately.
