// ─── STORAGE & SAVE ──────────────────────────────────────────────────────────
// NOTE: This project uses the Claude artifact storage API (window.storage).
// When running outside Claude, replace window.storage with localStorage shim below.
//
// localStorage shim (uncomment to use outside Claude):
// window.storage = {
//   async get(k){ const v=localStorage.getItem(k); return v?{key:k,value:v}:null; },
//   async set(k,v){ localStorage.setItem(k,v); return {key:k,value:v}; }
// };

let saveTimer = null;
function setDot(s,m){
  const d=el('hopDot'), t=el('hopStatus');
  if(d) d.className='save-dot '+s;
  if(t) t.textContent=m;
}
async function hopSave(manual){
  setDot('saving','Saving');
  try{
    const payload = {
      v:42, at:new Date().toISOString(),
      CD, REQS, NEEDS, PUB, QUICK,
      HK_FLOORS, HK_ROLES, HK_SUMMARY,
      SUP, EQ, DONE,
      hkDate: el('hkDate') ? el('hkDate').value : ''
    };
    const r = await window.storage.set(KEY, JSON.stringify(payload));
    if(r){
      setDot('saved','All changes saved');
      el('hopLast').textContent='Last saved '+new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
    } else setDot('error','Save failed');
  } catch(e){ setDot('error','Save error: '+e.message); }
}
function schedSave(){
  if(saveTimer) clearTimeout(saveTimer);
  setDot('saving','Unsaved changes');
  saveTimer = setTimeout(()=>hopSave(), 2000);
}

async function loadFromStorage(){
  try{
    const r = await window.storage.get(KEY);
    if(r && r.value){
      const j = JSON.parse(r.value);
      if(j.CD)   CD   = j.CD;
      if(j.REQS) REQS = j.REQS;
      if(j.NEEDS) NEEDS = Object.assign(NEEDS, j.NEEDS);
      if(j.PUB)  PUB  = j.PUB;
      if(j.QUICK) QUICK = Object.assign(QUICK, j.QUICK);
      if(j.HK_FLOORS)  HK_FLOORS  = j.HK_FLOORS;
      if(j.HK_ROLES)   HK_ROLES   = j.HK_ROLES;
      if(j.HK_SUMMARY) HK_SUMMARY = j.HK_SUMMARY;
      if(j.SUP)  SUP  = j.SUP;
      if(j.EQ)   EQ   = j.EQ;
      if(j.DONE) DONE = j.DONE;
      if(j.hkDate && el('hkDate')) el('hkDate').value = j.hkDate;
      return true;
    }
  } catch(e){ console.warn('Load failed:', e); }
  return false;
}